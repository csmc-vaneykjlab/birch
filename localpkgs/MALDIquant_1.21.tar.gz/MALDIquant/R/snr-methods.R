## MassPeaks
setMethod(f="snr",
          signature=signature(object="MassPeaks"),
          definition=function(object) {

  object@snr
})

## This is a MALDIquant example file. It is released into public domain with the
## right to use it for any purpose but without any warranty.


## all MALDIquant demos


library("MALDIquant")
demo("baseline", package="MALDIquant")
demo("peaks", package="MALDIquant")
demo("warping", package="MALDIquant")
message("demo(\"workflow\") produces no graphical output")
demo("workflow", package="MALDIquant")

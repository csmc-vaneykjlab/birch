# useful errors if too few or too many

    Code
      build_readme(pkg)
    Condition
      Error in `build_readme()`:
      ! Can't find 'README.Rmd' or 'inst/README.Rmd'.

---

    Code
      build_readme(pkg)
    Condition
      Error in `build_readme()`:
      ! Can't have both 'README.Rmd' and 'inst/README.Rmd'.


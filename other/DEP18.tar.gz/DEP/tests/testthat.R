library(testthat)
library(DEP)

test_check("DEP")

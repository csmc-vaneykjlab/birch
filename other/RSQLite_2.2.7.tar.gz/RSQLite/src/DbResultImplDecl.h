class SqliteResultImpl;
typedef SqliteResultImpl DbResultImpl;

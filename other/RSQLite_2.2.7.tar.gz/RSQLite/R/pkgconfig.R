pkgconfig_dummy <- function() {
  pkgconfig::get_config()
}
